package com.global.user.registrationService.repositories;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.global.user.registrationService.models.User;

public interface UserRepository  extends CrudRepository<User,String>{
	User findByUserid(String userid);
	
	Optional<User> findByEmailOrMobile(@Param("emailormobile") String emailormobile, @Param("password") String password);
}
