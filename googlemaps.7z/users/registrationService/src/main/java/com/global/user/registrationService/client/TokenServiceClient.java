package com.global.user.registrationService.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.global.user.registrationService.Dtos.TokenDto;
import com.global.user.registrationService.Dtos.UserDetailsDto;

@FeignClient(name="TokenServiceClient", url="${app.client.tokenservice.url}")
public interface TokenServiceClient {

	@PostMapping("/auth/token")
	public TokenDto GetToken(@RequestBody UserDetailsDto userDetailsDto);
	
}
