package com.global.user.registrationService.Dtos;

public class LoginDto {
	
	private String emailormobile;
	private String password;
	
	public String getEmailormobile() {
		return emailormobile;
	}
	public void setEmailormobile(String emailormobile) {
		this.emailormobile = emailormobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
