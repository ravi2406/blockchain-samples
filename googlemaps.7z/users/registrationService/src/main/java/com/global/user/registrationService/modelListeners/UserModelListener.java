package com.global.user.registrationService.modelListeners;

import javax.persistence.PrePersist;

import com.global.user.registrationService.models.User;

public class UserModelListener {

	@PrePersist
	public void onCreate(User user) {
		
	}
}
