package com.global.user.registrationService.controllers;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.global.user.registrationService.Dtos.LoginDto;
import com.global.user.registrationService.Dtos.RegisterDto;
import com.global.user.registrationService.Dtos.TokenDto;
import com.global.user.registrationService.Service.UserService;
import com.global.user.registrationService.models.User;
import com.global.user.registrationService.repositories.UserRepository;

@RestController
@RequestMapping("user")
//@CrossOrigin(origins = "http://localhost:4200") //temp way of allowing CORS must be done in at global level
public class RegisterController {
	
	@Autowired
	UserService _userService;
	
	@GetMapping("health")
	public String health( HttpServletRequest request) {
		return "am running. status request received from : " + request.getRemoteAddr();
	}
	
	@PostMapping("/register")
	public UUID addNewUser(@RequestBody RegisterDto registerDto, HttpServletRequest request) {
		
		return _userService.RegisterUser(registerDto);
	}
	
	@PostMapping("/login")
	public TokenDto login(@RequestBody LoginDto loginUser) throws Exception {
		String message = "Login Successful";
		TokenDto user = _userService.GetUserForLogin(loginUser);
		
		if(user == null)
			message = "Login Failed.";
		else
			message = "getting auth token";
		
		return user;

	}
	
	/*
	@GetMapping
	public User getUser(@RequestParam String userId ) {
		Optional<User> result =  _userRepository.findById(userId);
		return result.get();
	}
	
	@GetMapping("/{userId}")
	public User getUserByUserId(@PathVariable String userId ) {
		return _userRepository.findByUserid(userId);		
	}
	*/
}
