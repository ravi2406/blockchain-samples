package com.global.user.registrationService.Service;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.global.user.registrationService.Dtos.LoginDto;
import com.global.user.registrationService.Dtos.RegisterDto;
import com.global.user.registrationService.Dtos.TokenDto;
import com.global.user.registrationService.Dtos.UserDetailsDto;
import com.global.user.registrationService.client.TokenServiceClient;
import com.global.user.registrationService.models.User;
import com.global.user.registrationService.repositories.UserRepository;

class MobileNumberMap extends PropertyMap<RegisterDto,User>{

	@Override
	protected void configure() {
		map().setMobile_number(source.getMobile());		
	}
	
}

@Service
public class UserService {

	Logger logger = LoggerFactory.getLogger(UserService.class);
	@Autowired
	UserRepository _userRepository;
	
	@Autowired
	TokenServiceClient _tokenServiceClient;
	
	@Autowired
	ModelMapper _modelMapper;
	
	public UUID RegisterUser(RegisterDto registerDto) {
		_modelMapper.addMappings(new MobileNumberMap());
		//_modelMapper.addMappings(mapper -> mapper.map( RegisterDto::getMobile,User::setMobile_number));
		User user = _modelMapper.map(registerDto, User.class);
		user.setUserid(UUID.randomUUID());		
		user.setIs_active(true);
		user.setDate_created(new Date());
		User savedUser = _userRepository.save(user);
		return savedUser.getUserid();
	}
	
	public TokenDto GetUserForLogin(LoginDto loginDto){
	 Optional<User> user = _userRepository.findByEmailOrMobile(loginDto.getEmailormobile(), loginDto.getPassword());
	 TokenDto data = null;
	 if(user.isPresent()) {
		 logger.info("user found");
		 UserDetailsDto dto = _modelMapper.map(user.get(), UserDetailsDto.class);
		 data = _tokenServiceClient.GetToken(dto);
		 logger.info(data.getToken());
	 }
	 
	 return data;
	}
}
