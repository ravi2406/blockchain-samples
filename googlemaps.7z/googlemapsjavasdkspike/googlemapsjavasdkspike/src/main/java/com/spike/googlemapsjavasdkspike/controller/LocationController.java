package com.spike.googlemapsjavasdkspike.controller;

import java.util.Arrays;
import java.util.stream.*;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.AddressComponent;
import com.google.maps.model.AddressComponentType;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;
import com.spike.googlemapsjavasdkspike.model.AutoLocation;
import com.spike.googlemapsjavasdkspike.util.Helper;
import com.uber.h3core.H3Core;

@RestController
@RequestMapping("location")
public class LocationController {

	@Value("${app.gmapApiKey}")
	public String _gmapApiKey;
	
	
	
	@GetMapping("/pincode")
	public String getAddressFromLocation() {
		
		String postalCode = "N/A";
		LatLng loc = new LatLng();
		loc.lat = 13.006335;
		loc.lng = 77.646956;
		GeoApiContext context = new GeoApiContext.Builder()
			    .apiKey(_gmapApiKey)
			    .build();
		try {
			GeocodingResult[] results = GeocodingApi.reverseGeocode(context, loc).await();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();			
			//System.out.println(results[0].addressComponents.length);
			
			AddressComponent postalCodeComponent = Arrays.asList(results[0].addressComponents).stream()
					.filter(x -> Arrays.asList(x.types)
					.contains(AddressComponentType.POSTAL_CODE))
					.findFirst().get();					
			
			//System.out.println(postalCode);
			postalCode = postalCodeComponent.longName;						
			
		}catch(Exception ex) {
			
		}
		return postalCode;
	}
	
	@GetMapping("/auto/{pinCode}")
	public void GetNearbyAutosByPincode(@PathVariable String pinCode) {
		
		LatLng loc = new LatLng();
		loc.lat = 12.991344;//13.006335;
		loc.lng = 77.715741;//77.646956;
		
		Map<String,List<String>> nearbyPinCodes = Helper.getNearbyPincode(pinCode);
		List<AutoLocation> autosInPin = Helper.getAutosByPincodes(nearbyPinCodes.get(pinCode));
		
		for(AutoLocation auto : autosInPin) {
			int dist = Helper.calculateDistanceInKilometer(loc.lat, loc.lng, auto.lat, auto.lng);
			System.out.println(String.format("auto id : %d, dist: %d, pincode %s",auto.id,dist,auto.pinCode));
		}
		
	}
	
	@GetMapping("/nearbyauto/{pinCode}")
	public void GetNearbyAutosByCellId(@PathVariable String pinCode) {
		
		LatLng loc = new LatLng();
		loc.lat = 13.006335;//12.991344;//
		loc.lng = 77.646956;//77.715741;//
		
		try {
			
		
		H3Core h3 = H3Core.newInstance();
		
		String hexAddress = h3.geoToH3Address(loc.lat,loc.lng,9);
		System.out.println(hexAddress);
		
		System.out.println( h3.kRing(hexAddress, 2));
		
		Map<String,List<String>> nearbyPinCodes = Helper.getNearbyPincode(pinCode);
		List<AutoLocation> autosInPin = Helper.getAutosByPincodes(nearbyPinCodes.get(pinCode));
		
		for(AutoLocation auto : autosInPin) {		
			String autoHexAddress = h3.geoToH3Address(auto.lat,auto.lng,9);
			System.out.println(String.format("auto id : %d, hex: %s", auto.id, autoHexAddress));			
			int dist = Helper.calculateDistanceInKilometer(loc.lat, loc.lng, auto.lat, auto.lng);
			System.out.println(String.format("auto id : %d, dist: %d, pincode %s",auto.id,dist,auto.pinCode));
		}
		}catch(Exception ex) {
			
		}
	}
}
