package com.spike.googlemapsjavasdkspike.model;

public class AutoLocation{
	public int id;
	public String pinCode;
	public double lat;
	public double lng;
	
	public AutoLocation(int id, String pinCode, double lat, double lng) {
		this.id = id;
		this.pinCode = pinCode;
		this.lat = lat;
		this.lng = lng;
	}
}
