package com.spike.googlemapsjavasdkspike.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.*;

import com.spike.googlemapsjavasdkspike.model.AutoLocation;


public class Helper {
	
	public static Map<String,List<String>> getNearbyPincode(String pinCode){
		Map<String,List<String>> nearbyPincodeMap = new HashMap<>();
		
		nearbyPincodeMap.put("560043", Arrays.asList("560043", "560084","560048","560045"));
		
		return nearbyPincodeMap;
	}
	
	public static List<AutoLocation> getAutosByPincodes(List<String> pinCodeList){
		List<AutoLocation> autoLocationList = new ArrayList<>();
		autoLocationList.add(new AutoLocation(1,"560043",13.009605,77.644023));
		autoLocationList.add(new AutoLocation(2,"560043",13.008417,77.651800));
		autoLocationList.add(new AutoLocation(3,"560084",13.011112,77.628451));
		autoLocationList.add(new AutoLocation(4,"560048",12.991294,77.716206));
		autoLocationList.add(new AutoLocation(5,"560045",13.036130,77.631793));
		autoLocationList.add(new AutoLocation(6,"560084",13.010433,77.631425));
		
		//nearbyPincodeMap.put("560043", Arrays.asList("560084","560048","560045"));
		
		List<AutoLocation> result = autoLocationList.stream().filter(x -> pinCodeList.contains(x.pinCode) )
		.collect(Collectors.toList());
		
		return result;
	}
	
	public final static double AVERAGE_RADIUS_OF_EARTH_KM = 6371;
	public static int calculateDistanceInKilometer(double userLat, double userLng,
	  double venueLat, double venueLng) {

	    double latDistance = Math.toRadians(userLat - venueLat);
	    double lngDistance = Math.toRadians(userLng - venueLng);

	    double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
	      + Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(venueLat))
	      * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

	    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

	    return (int) (Math.round(AVERAGE_RADIUS_OF_EARTH_KM * c));
	}
}
